package com.polstat.perpustakaan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerpustakaanApplicationTests {

	@Test
	void contextLoads() {
	}

}
